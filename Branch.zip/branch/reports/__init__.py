# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import inherited_sale_report
from . import inherited_account_invoice_report
from . import inherited_purchase_report


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
