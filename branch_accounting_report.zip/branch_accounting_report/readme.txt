date 13th dec 2021
version 15.0.0.1
issue solve:-
profit loss report while remove branch and lines are unfold then raise traceback
